﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using DemoTEST.Repository;
using DemoTEST.Models;
using DemoTEST.Interfaces;

namespace DemoTEST.Controllers
{
    public class StudentController : Controller
    {
        private readonly StudentRepo _studentRepo;
        private readonly StudentDbContext _db;

        public StudentController(StudentRepo student, StudentDbContext student1)
        {
            _studentRepo = student;
            _db = student1;
        }
       
        public IActionResult Index()
        {
            return View(_db.Students.ToList());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Students student)
        {
            if (ModelState.IsValid)
            {
                _studentRepo.Create(student);
                return RedirectToAction("Index", "Student");
            }
            return View(student);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var student = _studentRepo.GetById(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        [HttpPost]
        public IActionResult Edit(Students student)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _studentRepo.Update(student);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "An error occurred while updating the student: " + ex.Message);
                }
            }
            return View(student);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var student = _studentRepo.GetById(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        [HttpPost]
        public IActionResult DeleteConfirmed(int id)
        {
            var student = _studentRepo.GetById(id);
            if (student == null)
            {
                return NotFound();
            }

            try
            {
                _studentRepo.Delete(student);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "An error occurred while deleting the student: " + ex.Message);
            }

            return View(student);
        }

        public IActionResult Details(int id)
        {
            var data = _db.Students.Where(x => x.Id == id).FirstOrDefault();
            return View(data);
        }
    }
}
