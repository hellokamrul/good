﻿using DemoTEST.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoTEST.Models;
using Microsoft.AspNetCore.Mvc;

namespace DemoTEST.Repository
{
    public class StudentRepo : IStudentInterface<Students>
    {
        StudentDbContext _dbcontext;
        public StudentRepo(StudentDbContext studentDbContext)
        {
            _dbcontext = studentDbContext;
        }

        public bool Create(Students _object)
        {

            var obj = _dbcontext.Add(_object);
            _dbcontext.SaveChanges();
            return true;
                
        }

        public bool Delete(Students _object)
        {
            try
            {
                var DataList = _dbcontext.Students.Where(x => x.Id==_object.Id).ToList();
                foreach (var item in DataList)
                {
                    _dbcontext.Remove(_object);
                    _dbcontext.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {
                return true;
            }
        }

        public IEnumerable<Students> GetAll()
        {
          return  _dbcontext.Students.ToList();
        }

       
            public Students GetById(int id)
            {
                return _dbcontext.Students.FirstOrDefault(s => s.Id == id);
            }

        
       
        public bool Update(Students _object)
        {
            
            try  
            {  
                var DataList = _dbcontext.Students.Where(x => x.Id != null).ToList();  
                foreach (var item in DataList)  
                {
                    _dbcontext.Students.Update(_object);
                    _dbcontext.SaveChanges();
                }  
                return true;  
            }  
            catch (Exception)  
            {  
                return true;  
            }  
        }
    }
}
